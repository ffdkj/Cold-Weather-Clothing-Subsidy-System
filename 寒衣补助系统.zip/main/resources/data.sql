insert into admin_user (id, username, password, role) values (1, 'a', 'rjxy', 'school');
insert into admin_user (id, username, password, role) values (2, 'counselor1', 'rjxy', 'counselor');
insert into admin_user (id, username, password, role) values (3, 'college1', 'rjxy', 'college');
insert into admin_user (id, username, password, role) values (4, 'school1', 'rjxy', 'school');

package com.rjxy.clothing.repo;

import com.rjxy.clothing.model.SubsidyBatch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubsidyBatchRepository extends JpaRepository<SubsidyBatch, Long> {
}

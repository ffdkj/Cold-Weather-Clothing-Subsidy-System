package com.rjxy.clothing.model;

public enum UserRole {
    STUDENT,
    COUNSELOR,
    COLLEGE,
    SCHOOL
}
